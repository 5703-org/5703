# Source04 isolated installation and runtime qualification

The frozen Source04 application passed actual PostgreSQL and TCP HTTP Mock runtime checks from a new extracted directory on 8 October 2026. Dependency installation was not performed. The delivered ZIP contains no wheelhouse or frontend dependency cache, so a fresh offline installation cannot be certified from this check. The existing Main Python virtual environment supplied dependencies. No Main file, existing database or protected experiment was changed.

The tested source is `CS30-1_Main_20261008_b94f69f894ce`. The complete Source04 delivery ZIP is 1,861,689,106 bytes with SHA-256 `11cc9f46f5d98b9d66ed3233ded5109eb369679737c649e662f5c8705a0c2856`. All 1,489 source members were extracted, checked against the ZIP manifest, and checked again against the final source index after runtime completion. Their total size is 51,698,997 bytes. No source member changed. The final source index SHA-256 is `88451d11075975db45e2102ffadf5e26f2190d4d03060ca6c3721993448ab890`. The answering service SHA-256 remains `0085621f56bea5971c5a6b4da47ad2441c33cc4ae66ae80e1ccd3f732a7c6499`.

The dedicated container `5703-source04-install-20261008-01-pg` used an already installed `pgvector/pgvector:0.8.6-pg16-trixie` image. The actual database reported PostgreSQL 16.15 and pgvector 0.8.6. The successful run used only the new synthetic database `cs30_source04_isolated_20261008_02`, bound to loopback port 15445. Fresh migration to `f9a05c2187de` and repeated migration to head passed. The API ran on loopback port 18045, using the candidate's unchanged factory and worker.

Nine check groups passed. The successful process, PID 97896, ran from 19:28:05.543227 to 19:28:10.911716 UTC. Its 63 HTTP requests include expected access and validation denials; the count is not a count of 2xx responses alone.

- Actual `/live`, `/health` and `/ready` returned 200; unauthenticated sessions returned 401. The generated OpenAPI path and schema sets matched the delivered contract: 124 paths and 234 schemas.
- Synthetic demo authentication, text upload, native processing job, Mock embedding/corpus build and activation succeeded.
- Two-turn Mock chat persisted answers, reused server-selected context, returned citations tied to exact evidence text hashes, and returned the expected message history.
- Repeated idempotency keys, conflicting submissions, busy-session rejection and forbidden gold-input validation returned the expected results. A social answer succeeded without evidence.
- Cross-account history access returned 404; student source-administration access returned 403. Archiving cancelled the owned pending job; a new session did not inherit the earlier conversation.

Four answers persisted: two factual answers, one social response and one clarification. Five answer requests existed, with three recorded Mock calls. Seven jobs were terminal: six succeeded, one cancelled. These are synthetic pipeline observations, not model-quality or learner-outcome measurements.

A separate process restarted the API without any message submission or worker execution. Actual HTTP reads verified all four existing answer IDs, request IDs and canonical response hashes; two cited evidence text hashes; and three session histories. This is durable restart/readback evidence. A browser was not used in this isolated candidate check.

The first harness attempt stopped before API readiness because its port restriction blocked Windows asyncio's internal loopback socketpair. Its migrations passed, and its failure receipt and script remain preserved. Only the workspace harness was corrected to allow loopback self-pipes, and the successful run used a second new synthetic database. No production code was patched. The original failure receipt's `external_network_attempts` entry describes that rejected local self-pipe; it was not an external provider request.

All API threads closed. The owned container was stopped and retained with both synthetic databases; no container, volume or test data was deleted. API port 18045 was checked free. There were zero paid/provider requests, external network attempts in the successful runs, image downloads, Main writes or existing-database modifications.

Evidence is in `ACTUAL_SOURCE04_EXTRACTION01.json`, `ACTUAL_OWNED_PG_READY01.json`, `ACTUAL_SOURCE04_RUNTIME02.json`, `ACTUAL_SOURCE04_RESTART_PERSISTENCE01.json` and `ACTUAL_SOURCE04_RUNTIME_CLOSURE01.json`. The first failure and the original two receipt labels remain separate preserved artifacts. `ACTUAL_RECEIPT_LABEL_CORRECTIONS01.json` explains that disk space measured after extraction is labelled accordingly and that 63 counts all HTTP checks, including expected denials.

Remaining qualification gaps are fresh dependency installation, the complete Windows launcher flow, frontend/browser behavior in this new installation, and installation of the full official corpus/model resources. The launcher `scripts/release/start_local.ps1 -Install` uses network `pip install` and `npm ci`; this task's offline scope did not authorize those downloads. A compatible offline wheelhouse and frontend package cache, or explicit authorization for the necessary dependency downloads, is required to complete that installation action. Global project completion, human acceptance and performance targets are not established by these checks.
