Public evidence package: designated supporting-fragment retrieval benchmark

Dense and default Hybrid: each10/12 designated supports in top5 (83.3333%).
12 questions,24 actual native executions; full search10594 public released
chunks, support selection3534 Biology2e chunks. Source-conditioned synthetic
questions and one support per question authored/annotated by one AI agent.
Not exhaustive relevance gold, representative user queries, or human validation.
Precision/MRR/nDCG and original SciQ12 relevance metrics remainNULL.

Exact original aggregate and all24 individual result files are included.
Raw textbook passages/source-unit text, database DSN/connection configuration,
authentication, private model configuration/keys, raw model messages/responses,
weights, vector values, archives and real user data are excluded. Public native
retrieval configuration/model revision identifiers are retained solely to make
conditions checkable; they contain no database credentials or provider keys.

OpenStax Biology2e: Mary Ann Clark, Jung Choi, Matthew Douglas.
Official PDF:https://assets.openstax.org/oscms-prodcms/media/documents/Biology-2e_-_WEB.pdf
Official preface:https://openstax.org/books/biology-2e/pages/preface
Source license recorded in inventory and current preface:
Creative Commons Attribution-NonCommercial-ShareAlike4.0.
https://creativecommons.org/licenses/by-nc-sa/4.0/
The source-conditioned questions/rationales are provided under this same license.
The frozen per-support pages/spans/textSHA refer to the acquired2026-09-08 PDF
and immutable native processing, not a newly downloaded or updated web text.

Original frozen benchmark SHA256:
0ad5237e7f69fcd5eb09ce0cd60ec2584556e31b6dcff69bd2111ca550730db3
Actual aggregate SHA256:
d76a52d981fbc84e4cbc41c5a1ce01596d1591b73973e32c816bdfe341701f53
See report and manifest for conditions, preserved failed pre-retrieval attempt,
all hashes, labels, candidate and ranked IDs, and numerical readback.
