# Closed reasoning-disabled five-case comparison

All five fixed DeepSeek V3.2 cases returned usable final JSON and passed the unchanged native decoder and strict E0 business schema. With the original references and conservative-v1 scorer, EM is 2/5 (0.4000), equal to the reused Gemini outcomes. Mean per-question token-overlap F1 is 0.5333 versus Gemini 0.4000: paired mean delta +0.1333, one win, four ties and zero losses. EM has zero wins, five ties and zero losses.

| Fixed case | Gemini EM | Disabled V3.2 EM | Gemini token F1 | Disabled V3.2 token F1 |
| --- | ---: | ---: | ---: | ---: |
| sciq:test:000008 | 0 | 0 | 0 | 0 |
| sciq:validation:000040 | 0 | 0 | 0 | 0.6667 |
| sciq:validation:000013 | 1 | 1 | 1 | 1 |
| sciq:test:000014 | 1 | 1 | 1 | 1 |
| sciq:test:000052 | 0 | 0 | 0 | 0 |

The sole DeepSeek request-parameter change from the original failed five-case condition is reasoning: effort low became enabled false. The original messages, json_object format, max_tokens 768, omitted sampling parameters and exclusive DeepInfra/fp4 route were preserved. This is a new condition with its own retained evidence. The original five effort-low failures and their unavailable semantic scores remain unchanged.

The first test000008 gate checked usable final content and native schema compatibility before continuation; no correctness score selected the gate. It scores zero here and remains in the fixed denominator. The four remaining cases followed their frozen order. No case was replaced or excluded. Gemini predictions and original metric flags came from the original pinned plan; all five flags reproduced exactly, with zero new Gemini requests. References were read only after Root confirmed both transports closed and after terminal, plan, case and source-pin checks.

Each new response was HTTP200 from DeepInfra, with returned deepseek/deepseek-v3.2, finish stop, no native decoder error, a final-content string and strict schema completed. All five report zero reasoning tokens. Final content alone was scored; no reasoning field was accessed, converted to an answer or scored. No answer, reference or reasoning text appears in this packet.

The five new requests have gateway-reported known cost USD0.00030326: first gate USD0.00007026 plus four-case continuation USD0.00023300. Usage totals are 1221 input, 94 output and 1315 total tokens. The last three cases each report 128 cached input tokens; the first two report none. Account balance and invoices were not checked. Full allocations remain retained: USD0.004 for the gate and USD0.012 for the continuation. Protected internal remainder is USD0.00127260. Current 233 project/103 follow-up limits are internal cumulative experiment-plan ceilings, not account quotas or balances. Both new batches are CLOSED/STOPPED, fully settled, with zero open/UNKNOWN/integrity/cleanup and no remaining released slot.

Observed DeepSeek durations span 1605.686-11758.702 ms, with median 2050.344 ms. They measure one physical provider POST through complete body capture and existing decode return. They exclude native question preparation, retrieval, production teacher/checker, SSE/UI rendering and persistence. Gemini's reused timing is its original adapter-return boundary on an earlier run. These clocks cannot establish a controlled cross-model latency improvement or complete-answer UI/p95 result. Gateway cache use and execution dates also differ.

The original scorer defines token F1 as multiset token overlap per question, averaged over all five scheduled questions. It is not class macro-F1, a human semantic score or a learning-effect measure. Five exposed DEV stems and a compatibility-gated continuation provide a small diagnostic comparison; they do not establish held-out generalization or a model ranking. These E0 cases contain no retrieved evidence, so they add no RAG relevance gold, Recall@K, MRR or nDCG evidence.

Offline scoring rehashed 462 frozen public source pins before and after, and terminal/plan pins remained unchanged. Transport metadata records original model configuration and active pointer unchanged; the scorer did not independently query the database pointer. Scoring and packaging made zero provider calls, credential reads, database operations or Main writes. Source04, old archives and all old/new raw evidence are preserved. No product compatibility patch or overall PROJECT acceptance is asserted.

The nested single-validation public ZIP is included byte-for-byte for provenance; this outer report and numeric five-case result provide the completed continuation. Private HTTP captures, real databases, provider input payloads, reference contents, response text and reasoning text are excluded.
